<div class="row">
    <div class="col-lg-12">
        <hr>
        <div class="widget-box widget-color-blue">
            <div class="widget-header">
                <div class="widget-title">Laporan Penjualan</div>
            </div>
            <div class="widget-body">
                <div class="widget-main">
                    <div class="table-responsive">
                        <a onclick="javascript:printContent('print_content')"><h2><i class="fa fa-print"></i></h2></a>
                        <div id="print_content">
                            <table class="table table-bordered">
                                <tr>
                                    <td>
                                        <img class="img-responsive" src="<?php echo base_url('assets/images/photo/tr_logo.png') ?>">
                                    </td>
                                    <td>
                                        <p>Laporan Penjualan</p>
                                        <p>2017-03-21 / 2017-04-21</p>
                                    </td>
                                </tr>
                            </table>
                            <table class="table table-bordered table-hover">
                                <tr class="bg-primary text-center">
                                    <th>KODE TRANSAKSI</th>
                                    <td colspan="2">Barang</td>
                                    <td>Qty</td>
                                    <td>Harga</td>
                                    <td>Diskon</td>
                                    <td>Sub Total</td>
                                </tr>
                                    <?php 
                                        foreach ($pj as $key) {
                                    ?>
                                            <tr class="bg-success text-center">
                                                <th colspan="7"><?php echo $key->id_penjualan; ?>
                                                </th>
                                                <tr>
                                                    <td><strong><?php echo $key->tgl_penjualan ?></strong></td>
                                                </tr>
                                                   <?php 
                                                        $tb = 0;
                                                        foreach ($dt_pj as $key2) {
                                                            if ($key2->id_penjualan==$key->id_penjualan) {
                                                    ?>
                                                            <tr class="text-center">
                                                                <td></td>
                                                                <td><?php echo $key2->id_barang ?></td>
                                                                <td><?php echo $key2->nama_barang ?></td>
                                                                <td><?php echo $key2->qty_terjual ?></td>
                                                                <td>
                                                                    <strong>Rp. <?php echo $this->cart->format_number($key2->harga_retail) ?></strong>
                                                                </td>
                                                                <td>
                                                                    <strong>Rp. <?php echo $this->cart->format_number($key2->total_diskon) ?>
                                                                    </strong>
                                                                </td>
                                                                <td><strong>Rp. <?php echo $this->cart->format_number($key2->sub_total) ?></strong></td>
                                                            </tr>
                                                    <?php 
                                                                $tb = $tb + $key2->sub_total;
                                                            }
                                                        }
                                                    ?>
                                                    <tr >
                                                        <td></td>
                                                        <td class="bg-info"><strong>Treatment</strong></td>
                                                        <td class="bg-info"><strong>Harga</strong></td>
                                                    </tr>
                                                    <?php 
                                                        $tt = 0;
                                                        foreach ($dt_tr as $key3) {
                                                            if ($key3->id_penjualan==$key->id_penjualan) {
                                                    ?>
                                                                <tr>
                                                                    <td></td>
                                                                    <td><?php echo $key3->nama_treatment ?></td>
                                                                    <td><?php echo $this->cart->format_number($key3->harga) ?></td>
                                                                </tr>
                                                    <?php 
                                                                $tt = $tt + $key3->harga;
                                                            }
                                                        }
                                                    ?>
                                                <td><strong>Total Belanja</strong></td>
                                                <td><strong>Total Treatment</strong></td>
                                                <td><strong>Diskon</strong></td>
                                                <td><strong>Total Transaksi</strong></td>
                                            </tr>
                                            <tr>
                                                <td><strong>Rp. <?php echo $this->cart->format_number($tb) ?></strong></td>
                                                <td><strong>Rp. <?php echo $this->cart->format_number($tt) ?></strong></td>
                                                <td><strong>Rp. <?php echo $this->cart->format_number($key->jumlah_diskon) ?></strong></td>
                                                <td class="bg-primary">
                                                    <?php 
                                                        $ttr = ($tb + $tt) - $key->jumlah_diskon;
                                                        echo "<strong>Rp. ".$this->cart->format_number($ttr)."</strong>";
                                                    ?>
                                                </td>
                                            </tr>
                                    <?php 
                                        }
                                    ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function printContent(el)
        {
            var restorepage = document.body.innerHTML;
            var printcontent = document.getElementById(el).innerHTML;
            document.body.innerHTML = printcontent;
            window.print();
            document.body.innerHTML = restorepage;
        }
    </script>
</div>