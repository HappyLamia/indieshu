<?php 
	/**
	* 
	*/
	class Test extends CI_Controller
	{
		public function index()
		{
			$this->load->view('v_test');
		}
		public function choose()
		{
			$array = array(array('id' => 1 , 'nama' => 'baju'),
						   array('id' => 1 , 'nama' => 'celana'),
						   array('id' => 2 , 'nama' => 'susu'),
						   array('id' => 3 , 'nama' => 'roti'),
						   array('id' => 4 , 'nama' => 'roti'),
						   array('id' => 4 , 'nama' => 'susu'),
						   array('id' => 4 , 'nama' => 'baju'));
			$new = array();
			foreach ($array as $opt) {
				$new[$opt['id']][] = $opt['nama'];
			}
			$output = array();
			foreach ($new as $id => $nama) {
				$output[] = array('id' => $id,
								  'nama' => $nama
								);
			}
			foreach ($output as $key => $value) {
				echo $key['id'];
			}
		}
		public function showValue()
		{
		 	$this->Mod_Query->get('result',)
		}
		public function bil()
		{
			for ($i=0; $i < 10; $i++) { 
				if ($i%2==0) {
					echo $i;
				}
			}
			echo "<br>";
			for ($i=0; $i < 10; $i++) { 
				if ($i%2!=0) {
					echo $i;
				}
			}
		}
		public function cart_brg()
		{
			$data = array(
			        array(
			                'id'      => 'sku_123ABC',
			                'qty'     => 1,
			                'price'   => 39.95,
			                'name'    => 'T-Shirt',
			                'options' => array('Size' => 'L', 'Color' => 'Red')
			        ),
			        array(
			                'id'      => 'sku_567ZYX',
			                'qty'     => 1,
			                'price'   => 9.95,
			                'name'    => 'Coffee Mug'
			        ),
			        array(
			                'id'      => 'sku_965QRS',
			                'qty'     => 1,
			                'price'   => 29.95,
			                'name'    => 'Shot Glass'
			        )
			);

			$this->cart->insert($data);
			redirect('test/index/');
		}
		public function cart_jasa()
		{
			$data = array(
			        'id'      => 'JX6876876A-9718923',
			        'qty'     => 1,
			        'price'   => 500,
			        'name'    => 'Kaos',
			        'options' => array('type'=>'Jasa')
			);
			$this->cart->insert($data);
			redirect('test/index/');
		}
		public function clear()
		{
			$this->cart->destroy();
			redirect('test/index/');
		}
	}
?>